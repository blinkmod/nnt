#!/usr/bin/env bash

. /hive/miners/custom/miner-hiveos/h-manifest.conf

algo="BLAKE3"

maxDelay=120
time_now=`date '+%s'`
time_log=`stat -c %Y $CUSTOM_LOG_BASENAME.log 2>/dev/null || echo 0`

if [[ ! -f "$CUSTOM_LOG_BASENAME.log" ]]; then
    time_log=0
else
    log_size=$(wc -l < "$CUSTOM_LOG_BASENAME.log" 2>/dev/null || echo 0)
    [[ $log_size -lt 5 ]] && time_log=0
fi

tail -n 10 $CUSTOM_LOG_BASENAME.log 2>/dev/null | grep -qi "Disconnected\|error\|failed\|timeout" && time_log=0

if (( time_now < time_log + maxDelay )); then
    ac=`grep -c "New task received\|Heartbeat success" "$CUSTOM_LOG_BASENAME.log" 2>/dev/null || echo 0`
    rj=0

    if [[ -f "$GPU_STATS_JSON" ]]; then
        busids=($(jq -r '.busids[]' "$GPU_STATS_JSON" 2>/dev/null))
        brands=($(jq -r '.brand[]' "$GPU_STATS_JSON" 2>/dev/null))
        temps=($(jq -r '.temp[]' "$GPU_STATS_JSON" 2>/dev/null))
        fans=($(jq -r '.fan[]' "$GPU_STATS_JSON" 2>/dev/null))
    else
        echo "null"
        exit 0
    fi

    hash_arr=()
    busid_arr=()
    fan_arr=()
    temp_arr=()
    total_hashrate=0

    declare -A card_speeds
    while IFS= read -r line; do
        if [[ "$line" =~ Card-([0-9]+)\ speed:\ +([0-9]+\.[0-9]+)\ p/s ]]; then
            card_num="${BASH_REMATCH[1]}"
            speed="${BASH_REMATCH[2]}"
            [[ -z "${card_speeds[$card_num]}" ]] && card_speeds[$card_num]="$speed"
        fi
    done < <(tac "$CUSTOM_LOG_BASENAME.log" 2>/dev/null | head -n 50)

    gpu_index=0
    for(( i=0; i < ${#busids[@]}; i++ )); do
        brand="${brands[i]}"
        busid="${busids[i]}"
        temp="${temps[i]}"
        fan="${fans[i]}"
        
        [[ "$brand" != "nvidia" && "$brand" != "amd" ]] && continue
        
        [[ "$busid" =~ ^([A-Fa-f0-9]+): ]]
        busid_decimal=$((16#${BASH_REMATCH[1]}))
        
        hash="0"
        if [[ -n "${card_speeds[$gpu_index]}" ]]; then
            hash="${card_speeds[$gpu_index]}"
        else
            for card_id in "${!card_speeds[@]}"; do
                if [[ -n "${card_speeds[$card_id]}" && "${card_speeds[$card_id]}" != "0.00" ]]; then
                    hash="${card_speeds[$card_id]}"
                    break
                fi
            done
        fi
        
        hash_arr+=("$hash")
        busid_arr+=("$busid_decimal")
        temp_arr+=("$temp")
        fan_arr+=("$fan")
        
        total_hashrate=$(echo "$total_hashrate + $hash" | bc -l 2>/dev/null || awk "BEGIN {print $total_hashrate + $hash}")
        ((gpu_index++))
    done

    hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
    bus_numbers=`printf '%s\n' "${busid_arr[@]}" | jq -cs '.'`
    fan_json=`printf '%s\n' "${fan_arr[@]}" | jq -cs '.'`
    temp_json=`printf '%s\n' "${temp_arr[@]}" | jq -cs '.'`

    uptime=$(( time_now - `stat -c %Y $CUSTOM_CONFIG_FILENAME 2>/dev/null || echo $time_now` ))
    [[ $uptime -lt 0 ]] && uptime=0
    version="$CUSTOM_VERSION"

    stats=$(jq -nc \
        --argjson hs "$hash_json"\
        --arg ver "$version" \
        --arg algo "$algo" \
        --argjson bus_numbers "$bus_numbers" \
        --argjson fan "$fan_json" \
        --argjson temp "$temp_json" \
        --arg ac "$ac" --arg rj "$rj" \
        --arg uptime "$uptime" \
           '{ $hs, hs_units: "p/s", $algo, $ver, $uptime, $bus_numbers, $temp, $fan, ar: [$ac|tonumber, $rj|tonumber] }')
    
    khs="$total_hashrate"
else
    khs=0
    stats="null"
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"

echo "$stats"