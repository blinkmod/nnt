#!/bin/bash

# pfad
logfile="/var/log/miner/custom/custom.log"
conf_file="/hive/miners/custom/oxzd_HiveOS_x86_64_latest/h-config.sh"
oxzd_conf="/hive/miners/custom/oxzd_HiveOS_x86_64_latest/oxzd.conf"

# standardwerte
total_khs=0
declare -a hs temp fan bus_numbers
gpu_count=0
algo="unknown"
hs_units="mhs"
accepted_shares=0
rejected_shares=0

# miner log
miner_log=$(tail -n 300 "$logfile" 2>/dev/null || echo "")

# konfiguration
main_algo_gpu=$(jq -r '.main_algo_gpu // ""' "$oxzd_conf" 2>/dev/null || echo "")
main_algo_cpu=$(jq -r '.main_algo_cpu // ""' "$oxzd_conf" 2>/dev/null || echo "")
gpu_idle_command=$(jq -r '.gpu_idle_command // ""' "$oxzd_conf" 2>/dev/null || echo "")

# gpu zaehlen
gpu_count=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | wc -l) # Wie viele GPUs sind da?
gpu_count=${gpu_count:-0}

# nvidia-smi stats
gpu_stats_raw=$(nvidia-smi --query-gpu=temperature.gpu,fan.speed,pci.bus_id --format=csv,noheader,nounits 2>/dev/null | sed 's/ //g') # Hol die Rohdaten (Temp, Fan, Bus-ID).

# fallback: log entscheidet
if [[ -z "$main_algo_gpu" && -z "$main_algo_cpu" ]] && echo "$miner_log" | grep -q "tip5"; then
  if echo "$miner_log" | grep -q "GPU[0-9]"; then
    main_algo_gpu="tip5"
  else
    main_algo_cpu="neptune"
  fi
fi

# --- extract tip5 gpu ---
extract_tip5_gpu() {
  total_line=$(echo "$miner_log" | grep -E "Total \| tip5:[[:space:]]*[0-9.]+" | tail -n1) # Gesamt-MHS aus dem Log holen.
  if [[ $total_line =~ Total\ \|\ tip5:[[:space:]]*([0-9]+\.[0-9]+) ]]; then
    total_mhs="${BASH_REMATCH[1]}"
    total_khs=$(echo "scale=0; $total_mhs * 1000 / 1" | bc 2>/dev/null || echo 0)
  else
    total_mhs=$(echo "$miner_log" | grep -oE "[0-9]+\.[0-9]+ MH/s" | awk '{sum += $1} END {print sum+0}')
    total_khs=$(echo "scale=0; $total_mhs * 1000 / 1" | bc 2>/dev/null || echo 0)
  fi

  for ((i=0; i<gpu_count; i++)); do # Hashrate pro GPU aus dem Log holen.
    line=$(echo "$miner_log" | grep -m1 "GPU$i.*MH/s")
    if [[ $line =~ ([0-9]+\.[0-9]+)[[:space:]]MH/s ]]; then
      mhs="${BASH_REMATCH[1]}"
      hs[$i]=$(echo "scale=0; $mhs * 1000 / 1" | bc 2>/dev/null || echo 0)
    else
      hs[$i]=0
    fi
  done

  accepted_shares=$(echo "$miner_log" | grep -c "Solution was accepted" 2>/dev/null || echo 0)
  rejected_shares=0

  # *** KORREKTE BUS NUMMERN: 0000:01:00.0 -> 01 -> 1 ***
  # FIX: Die if-Bedingung wird hier entfernt, damit alle GPUs erfasst werden,
  # selbst wenn nvidia-smi keine saubere Bus-ID liefert.
  j=0
  while IFS=',' read -r t f b; do
    if [[ $j -ge $gpu_count ]]; then # Nicht mehr GPUs verarbeiten, als wir gezählt haben.
        break
    fi

    # Bus-ID extrahieren (z.B. 0000:01:00.0 -> 01 -> 1)
    bus_hex=$(echo "$b" | cut -d':' -f2 | cut -d'.' -f1 2>/dev/null || echo "00")
    bus_dec=$(echo "ibase=16; ${bus_hex^^}" | bc 2>/dev/null || echo 0)
    
    # Daten einfach speichern, wie sie kommen.
    temp[$j]="$t"
    fan[$j]="$f"
    bus_numbers[$j]="$bus_dec"
    ((j++))
  done <<< "$gpu_stats_raw"

  for ((i=$j; i<gpu_count; i++)); do # Fehlende Werte auf 0 setzen.
    temp[$i]=0
    fan[$i]=0
    bus_numbers[$i]=0
  done

  algo="TIP5"
  hs_units="mhs"
}

# --- extract neptune-cpu ---
extract_neptune_cpu() {
  total_line=$(echo "$miner_log" | grep -E "Total \| tip5:[[:space:]]*[0-9.]+" | tail -n1)
  if [[ $total_line =~ Total\ \|\ tip5:[[:space:]]*([0-9]+\.[0-9]+) ]]; then
    total_mhs="${BASH_REMATCH[1]}"
    total_khs=$(echo "scale=0; $total_mhs * 1000 / 1" | bc 2>/dev/null || echo 0)
    hs[0]=$(echo "scale=0; $total_mhs * 1000 / 1" | bc 2>/dev/null || echo 0)
  else
    total_khs=0
    hs[0]=0
  fi

  accepted_shares=$(echo "$miner_log" | grep -c "Solution was accepted" 2>/dev/null || echo 0)
  rejected_shares=0

  temp[0]=$(cpu-temp 2>/dev/null || echo 0)
  fan[0]=0
  bus_numbers[0]=0

  algo="TIP5"
  hs_units="mhs"
}

# --- extract tari ---
extract_tari_stats() {
  total_line=$(echo "$miner_log" | grep -E "Total \| tari-sha3x:" | tail -n1)
  if [[ $total_line =~ ([0-9]+\.[0-9]+) ]]; then
    total_mhs="${BASH_REMATCH[1]}"
    total_khs=$(echo "scale=0; $total_mhs * 1000 / 1" | bc 2>/dev/null || echo 0)
  else
    total_khs=0
  fi

  for ((i=0; i<gpu_count; i++)); do
    line=$(echo "$miner_log" | grep -m1 "GPU$i.*MH/s")
    if [[ $line =~ ([0-9]+\.[0-9]+)[[:space:]]MH/s ]]; then
      mhs="${BASH_REMATCH[1]}"
      hs[$i]=$(echo "scale=0; $mhs * 1000 / 1" | bc 2>/dev/null || echo 0)
    else
      hs[$i]=0
    fi
  done

  accepted_shares=$(echo "$miner_log" | grep -c "Solution was accepted by pool")
  rejected_shares=$(echo "$miner_log" | grep -c "Solution was rejected by pool")

  # FIX: Busnummern-Parsing korrigiert, um alle GPUs zu erfassen.
  j=0
  while IFS=',' read -r t f b; do
    if [[ $j -ge $gpu_count ]]; then
        break
    fi
    bus_hex=$(echo "$b" | cut -d':' -f2 | cut -d'.' -f1 2>/dev/null || echo "00")
    bus_dec=$(echo "ibase=16; ${bus_hex^^}" | bc 2>/dev/null || echo 0)
    
    temp[$j]="$t"
    fan[$j]="$f"
    bus_numbers[$j]="$bus_dec"
    ((j++))
  done <<< "$gpu_stats_raw"

  for ((i=$j; i<gpu_count; i++)); do
    temp[$i]=0
    fan[$i]=0
    bus_numbers[$i]=0
  done

  algo="TARI"
  hs_units="mhs"
}

# --- extract xelishashv2 ---
extract_xelishashv2_stats() {
  total_line=$(echo "$miner_log" | grep -E "Total: [0-9.]+ KH/s" | tail -n1)
  if [[ $total_line =~ Total:[[:space:]]*([0-9.]+) ]]; then
    total_khs="${BASH_REMATCH[1]}"
  else
    total_khs=0
  fi

  for ((i=0; i<gpu_count; i++)); do
    line=$(echo "$miner_log" | grep -m1 "\|$i\|")
    if [[ $line =~ \|$i\|[^|]+\|([0-9.]+) ]]; then
      hs[$i]="${BASH_REMATCH[1]}"
    else
      hs[$i]=0
    fi
  done

  if [[ $total_line =~ \|([0-9]+)\|([0-9]+)\| ]]; then
    accepted_shares="${BASH_REMATCH[1]}"
    rejected_shares="${BASH_REMATCH[2]}"
  else
    accepted_shares=0
    rejected_shares=0
  fi

  # FIX: Busnummern-Parsing korrigiert, um alle GPUs zu erfassen.
  j=0
  while IFS=',' read -r t f b; do
    if [[ $j -ge $gpu_count ]]; then
        break
    fi
    bus_hex=$(echo "$b" | cut -d':' -f2 | cut -d'.' -f1 2>/dev/null || echo "00")
    bus_dec=$(echo "ibase=16; ${bus_hex^^}" | bc 2>/dev/null || echo 0)
    
    temp[$j]="$t"
    fan[$j]="$f"
    bus_numbers[$j]="$bus_dec"
    ((j++))
  done <<< "$gpu_stats_raw"

  for ((i=$j; i<gpu_count; i++)); do
    temp[$i]=0
    fan[$i]=0
    bus_numbers[$i]=0
  done

  algo="XEL"
  hs_units="hs"
}

# --- extract qubic ---
extract_qubic_stats() {
  total_line=$(echo "$miner_log" | grep -E "\[CUDA\][[:space:]]*[0-9]+" | tail -n1)
  if [[ $total_line =~ \[CUDA\][[:space:]]*([0-9]+) ]]; then
    total_khs="${BASH_REMATCH[1]}"
  else
    total_khs=0
  fi

  for ((i=0; i<gpu_count; i++)); do
    line=$(echo "$miner_log" | grep -m1 "GPU #$i:")
    if [[ $line =~ GPU\ #$i:[[:space:]]*([0-9]+) ]]; then
      hs[$i]="${BASH_REMATCH[1]}"
    else
      hs[$i]=0
    fi
  done

  accepted_shares=0
  rejected_shares=0
  algo="QUBIC"
  hs_units="its"
}

# --- extract cpu xelis ---
extract_cpu_xelis_stats() {
  total_line=$(echo "$miner_log" | grep -E "Total \| xelis-v2:" | tail -n1)
  if [[ $total_line =~ ([0-9.]+)[[:space:]]kH/s ]]; then
    total_khs="${BASH_REMATCH[1]}"
    hs[0]="$total_khs"
  else
    total_khs=0
    hs[0]=0
  fi
  temp[0]=$(cpu-temp 2>/dev/null || echo 0)
  fan[0]=0
  bus_numbers[0]=0

  algo="XEL"
  hs_units="hs"
}

# --- algo auswahl ---
selected="unknown"

if [[ "$main_algo_gpu" == "tip5" ]]; then
  selected="gpu-tip5"
elif [[ "$main_algo_cpu" == "neptune" ]]; then
  selected="neptune-cpu"
elif [[ -n "$main_algo_cpu" ]]; then
  selected="cpu-xelis"
fi

# idle befehle
if [[ "$selected" == "gpu-tip5" ]]; then
  if [[ "$gpu_idle_command" == *"xelishashv2"* ]] && echo "$miner_log" | grep -q "xelishashv2"; then
    selected="xelishashv2"
  elif [[ "$gpu_idle_command" == *"qubic"* ]] && echo "$miner_log" | grep -q "CUDA"; then
    selected="qubic"
  elif [[ "$gpu_idle_command" == *"tari"* ]] && echo "$miner_log" | grep -q "tari-sha3x"; then
    selected="tari"
  fi
fi

# fallback: log entscheidet
if [[ "$selected" == "unknown" ]] && echo "$miner_log" | grep -q "tip5"; then
  if echo "$miner_log" | grep -q "GPU[0-9]"; then
    selected="gpu-tip5"
  else
    selected="neptune-cpu"
  fi
fi

# --- stats aufrufen ---
case "$selected" in
  "gpu-tip5") extract_tip5_gpu ;;
  "neptune-cpu") extract_neptune_cpu ;;
  "tari") extract_tari_stats ;;
  "xelishashv2") extract_xelishashv2_stats ;;
  "qubic") extract_qubic_stats ;;
  "cpu-xelis") extract_cpu_xelis_stats ;;
  *)
    total_khs=0
    for ((i=0; i<6; i++)); do hs[$i]=0; temp[$i]=0; fan[$i]=0; bus_numbers[$i]=0; done
    algo="unknown"
    hs_units="hs"
    ;;
esac

# uptime
uptime=0
if [[ -f "$logfile" && -f "$conf_file" ]]; then
  log_time=$(stat -c %Y "$logfile" 2>/dev/null || echo 0)
  conf_time=$(stat -c %Y "$conf_file" 2>/dev/null || echo 0)
  ((uptime = log_time - conf_time))
fi

# version
ver=$(echo "$miner_log" | grep -o "OXZD [0-9.]*" | tail -n1 | grep -o "[0-9.]*" || echo "0.7.1")
ver="OXZD $ver"

# --- json sicher bauen ---
# Das hier baut die Arrays in sauberes JSON um und setzt bei Fehler '[]'.
hs_json=$(printf '%s\n' "${hs[@]:-0}" | jq -R -s -c 'split("\n") | map(select(length > 0) | tonumber?)' || echo '[]')
temp_json=$(printf '%s\n' "${temp[@]:-0}" | jq -R -s -c 'split("\n") | map(select(length > 0) | tonumber?)' || echo '[]')
fan_json=$(printf '%s\n' "${fan[@]:-0}" | jq -R -s -c 'split("\n") | map(select(length > 0) | tonumber?)' || echo '[]')
bus_json=$(printf '%s\n' "${bus_numbers[@]:-0}" | jq -R -s -c 'split("\n") | map(select(length > 0) | tonumber?)' || echo '[]')
ar_json="[$accepted_shares,$rejected_shares]"

stats=$(jq -nc \
  --argjson total_khs "$total_khs" \
  --argjson hs "$hs_json" \
  --arg hs_units "$hs_units" \
  --argjson temp "$temp_json" \
  --argjson fan "$fan_json" \
  --argjson bus_numbers "$bus_json" \
  --arg uptime "$uptime" \
  --arg ver "$ver" \
  --argjson ar "$ar_json" \
  --arg algo "$algo" \
  '{total_khs:$total_khs, hs:$hs, hs_units:$hs_units, temp:$temp, fan:$fan, bus_numbers:$bus_numbers, uptime:$uptime, ver:$ver, ar:$ar, algo:$algo}')

# ausgabe
echo "$total_khs"
echo "$stats"