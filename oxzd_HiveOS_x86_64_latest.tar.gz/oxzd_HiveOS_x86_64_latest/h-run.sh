#!/bin/bash

# Pfade
LOGFILE="/var/log/miner/custom/custom.log"
> "$LOGFILE" # clear before start
MINER_DIR=$(dirname "$(readlink -f "$0")")
CONFIG_FILE="$MINER_DIR/oxzd_config.json"
OXZD_CONF="$MINER_DIR/oxzd.conf"
QUBIC_DIR="/hive/miners/custom/qubminer"
QLI_CLIENT="$QUBIC_DIR/qli-Client"
APPSETTINGS_FILE="$QUBIC_DIR/appsettings.json"
APPSETTINGS_PROD_FILE="$QUBIC_DIR/appsettings.production.json"
QLI_WRAPPER="$QUBIC_DIR/run_qli.sh"

# Prüfe, ob oxzd.conf existiert
if [[ ! -f "$OXZD_CONF" ]]; then
    echo "[OXZD] ERROR: oxzd.conf nicht gefunden!"
    exit 1
fi

# Prüfe, ob die Konfiguration ein gültiges JSON-Format hat
jq . "$OXZD_CONF" >/dev/null 2>&1
if [[ $? -ne 0 ]]; then
    echo "[OXZD] ERROR: Konfigurationsdatei $OXZD_CONF ist kein gültiges JSON!"
    echo "[OXZD] Inhalt der oxzd.conf:"
    cat "$OXZD_CONF"
    exit 1
fi

# Lese die Konfiguration aus oxzd.conf
GPU_IDLE_COMMAND=$(jq -r '.gpu_idle_command // ""' "$OXZD_CONF")
CPU_IDLE_COMMAND=$(jq -r '.cpu_idle_command // ""' "$OXZD_CONF")
MAIN_ALGO_GPU=$(jq -r '.main_algo_gpu // ""' "$OXZD_CONF")
MAIN_ALGO_CPU=$(jq -r '.main_algo_cpu // ""' "$OXZD_CONF")
NPT_ADDRESS=$(jq -r '.npt_address // ""' "$OXZD_CONF")
XELIS_ADDRESS=$(jq -r '.xelis_address // ""' "$OXZD_CONF")
QUBIC_ADDRESS=$(jq -r '.qubic_address // ""' "$OXZD_CONF")
POOL_NEPTUNE=$(jq -r '.npt_url // "stratum+ssl://eu.poolhub.io:4444"' "$OXZD_CONF")
POOL_XELIS=$(jq -r '.xelis_url // "stratum+tcp://xelis.mine.zergpool.com:5555"' "$OXZD_CONF")
TARI_ADDRESS=$(jq -r '.tari_address // ""' "$OXZD_CONF")
POOL_TARI=$(jq -r '.tari_url // "stratum+tcp://de-eu.luckypool.io:6118"' "$OXZD_CONF")
# NEW: Read worker_name from oxzd.conf, default to hostname
WORKER_NAME=$(jq -r '.worker_name // ""' "$OXZD_CONF")
if [[ -z "$WORKER_NAME" ]]; then
    WORKER_NAME=$(hostname)
fi

# Prüfe, ob mindestens ein Algorithmus ausgewählt ist
if [[ -z "$MAIN_ALGO_GPU" && -z "$MAIN_ALGO_CPU" ]]; then
    echo "[OXZD] ERROR: Mindestens ein Algorithmus (main_algo_gpu oder main_algo_cpu) muss ausgewählt sein!"
    exit 1
fi

# Prüfe, ob Adressen gesetzt sind
if [[ -z "$NPT_ADDRESS" && ( "$MAIN_ALGO_CPU" == "neptune" || "$MAIN_ALGO_GPU" == "neptune" ) ]]; then
    echo "[OXZD] ERROR: npt_address muss gesetzt sein für Neptune!"
    exit 1
fi
if [[ -z "$XELIS_ADDRESS" && "$MAIN_ALGO_CPU" == "xelis" ]]; then
    echo "[OXZD] ERROR: xelis_address muss gesetzt sein für Xelis-CPU!"
    exit 1
fi
if [[ "$GPU_IDLE_COMMAND" == "qubic" && -z "$QUBIC_ADDRESS" ]]; then
    echo "[OXZD] ERROR: qubic_address muss gesetzt sein für Qubic-GPU!"
    exit 1
fi
if [[ "$CPU_IDLE_COMMAND" == "qubic" && -z "$QUBIC_ADDRESS" ]]; then
    echo "[OXZD] ERROR: qubic_address muss gesetzt sein für Qubic-CPU!"
    exit 1
fi
if [[ "$GPU_IDLE_COMMAND" == "tari" && -z "$TARI_ADDRESS" ]]; then
    echo "[OXZD] ERROR: tari_address muss gesetzt sein für Tari-GPU!"
    exit 1
fi

# Ermittle die Anzahl der verfügbaren CPU-Threads
AVAILABLE_THREADS=$(nproc)
if [[ "$AVAILABLE_THREADS" -lt 1 ]]; then
    AVAILABLE_THREADS=1
fi

# Funktion zum Download des Qubic-Miners
download_qubic_miner() {
    if [[ ! -f "$QLI_CLIENT" ]]; then
        echo "[OXZD] Qubic-Miner (qli-Client) nicht gefunden, lade herunter..."
        mkdir -p "$QUBIC_DIR"
        QLI_URL="https://dl.qubic.li/downloads/qli-Client-3.2.0-Linux-x64.tar.gz"        
        wget -O "$QLI_CLIENT" "$QLI_URL" || {
            echo "[OXZD] ERROR: Download von qli-Client fehlgeschlagen!"
            exit 1
        }
        chmod +x "$QLI_CLIENT"
        chown nobody:nogroup "$QLI_CLIENT"
        echo "[OXZD] qli-Client erfolgreich heruntergeladen und ausführbar gemacht."
    fi
    if [[ ! -x "$QLI_CLIENT" ]]; then
        echo "[OXZD] ERROR: qli-Client ist nicht ausführbar!"
        exit 1
    fi
}

# Funktion zum Erstellen eines Wrapper-Skripts für Qubic
create_qubic_wrapper() {
    cat > "$QLI_WRAPPER" << EOF
#!/bin/bash
cd "$QUBIC_DIR" || { echo "[OXZD] ERROR: Kann Verzeichnis $QUBIC_DIR nicht öffnen"; exit 1; }
echo "[OXZD] Starte qli-Client in Verzeichnis: \$PWD"
echo "[OXZD] Verfügbare Konfigurationsdateien:"
ls -l "$QUBIC_DIR/appsettings.json" "$QUBIC_DIR/appsettings.production.json" 2>/dev/null
exec ./qli-Client
EOF
    chmod +x "$QLI_WRAPPER"
    chown nobody:nogroup "$QLI_WRAPPER"
    echo "[OXZD] Wrapper-Skript $QLI_WRAPPER erstellt."
}

# Funktion zum Erstellen der appsettings.json für Qubic
create_qubic_appsettings() {
    local mode="$1"  # "gpu" oder "cpu"
    local pps_value="$2"  # "true" oder "false"
    local pool_address="$3"
    local worker_name="$WORKER_NAME"
    if [[ "$mode" == "cpu" ]]; then
        worker_name="qli Sturgeon"
    fi

    local access_token="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJJZCI6Ijc2ZDM5MjllLTI3ZmItNGRjNC04MzNkLTQyNmJkYzFlOGI5NSIsIk1pbmluZyI6IiIsIm5iZiI6MTczODgwNzE1OCwiZXhwIjoxNzcwMzQzMTU4LCJpYXQiOjE3Mzg4MDcxNTgsImlzcyI6Imh0dHBzOi8vcXViaWMubGkvIiwiYXVkIjoiaHR0cHM6Ly9xdWJpYy5saS8ifQ.snRGOlvID_LQ32tj75yd-bgkBbfCWLgM0CkNvZIjxp2jRemg2LvTGyc_ExQje3Iu_PCxLQCKjgmUPjoVt0NRZX1S1G13SNLWhyetzu1Dgu6QeO30hNdD7V06mcs13uRuMYfuD1BWLLXnXMShRUQQSWJSh6jFllPjwzW9RwycKncZ5VV7B1tr1__hES_dEnajTSBTcTIbNWgfXZGuzMvC6Re-Xvtf7DtFY17wDVQay52Q58SrflqSQ3LEmtGtZPLz0Pcj0F3fVCdQ6CzvbOov28TRG_CGv9ybFSm2WOfyY3L6h1jJRN9NtwN0I3QHIJuEoarKAB61vLqo62GLbQQFig"

    if [[ -f "$APPSETTINGS_PROD_FILE" ]]; then
        echo "[OXZD] Entferne $APPSETTINGS_PROD_FILE, um appsettings.json zu priorisieren."
        rm -f "$APPSETTINGS_PROD_FILE"
    fi

    local Settings='{
        "poolAddress": "",
        "alias": "",
        "accessToken": "",
        "qubicAddress": null,
        "pps": true,
        "trainer": {
            "cpu": false,
            "gpu": false,
            "cpuThreads": 0,
            "cpuVersion": "",
            "gpuVersion": "CUDA",
            "gpuCards": null,
            "cpuAffinity": null,
            "cpuVariant": null,
            "gpuVariant": null,
            "cpuName": null,
            "gpuName": null,
            "downloadUrlRewrites": null
        },
        "idling": null
    }'

    Settings=$(jq --arg poolAddress "ws://pps.qubic.solutions/ws/$pool_address" \
                  --arg alias "$worker_name" \
                  --arg accessToken "$access_token" \
                  --argjson pps "$pps_value" \
                  '.poolAddress = $poolAddress | 
                   .alias = $alias | 
                   .accessToken = $accessToken | 
                   .pps = $pps' <<< "$Settings")

    if [[ "$mode" == "gpu" ]]; then
        Settings=$(jq '.trainer.cpu = false | 
                       .trainer.gpu = true | 
                       .trainer.cpuThreads = 0 | 
                       .trainer.cpuVersion = "" | 
                       .trainer.gpuVersion = "CUDA"' <<< "$Settings")
    elif [[ "$mode" == "cpu" ]]; then
        Settings=$(jq '.trainer.cpu = true | 
                       .trainer.gpu = false | 
                       .trainer.cpuThreads = -1 | 
                       .trainer.cpuVersion = "AVX512" | 
                       .trainer.gpuVersion = "CUDA"' <<< "$Settings")
    fi

    echo "{\"ClientSettings\":$Settings}" | jq . > "$APPSETTINGS_FILE"
    chmod 644 "$APPSETTINGS_FILE"
    chown nobody:nogroup "$APPSETTINGS_FILE"
    echo "[OXZD] appsettings.json für Qubic ($mode) erstellt in $APPSETTINGS_FILE"
    echo "[OXZD] Inhalt von appsettings.json:"
    cat "$APPSETTINGS_FILE"
}

# Funktion zum Erstellen der oxzd_config.json
create_config() {
    local selected_algo="$1"
    local algo_list=()

    # Bestimme den Idle-Algorithmus
    local idle_algo_id=""
    # Add main algorithm first
    case "$selected_algo" in
        "neptune-gpu")
            algo_list+=("{\"id\": \"neptune-gpu\", \"algo\": \"neptune\", \"pool\": \"$POOL_NEPTUNE\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$NPT_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"gpu\", \"option\": \"all\"}, \"idle_algos\": [\"$idle_algo_id\"]}")
            ;;
        "neptune-cpu")
            algo_list+=("{\"id\": \"neptune-cpu\", \"algo\": \"neptune\", \"pool\": \"$POOL_NEPTUNE\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$NPT_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"cpu\", \"threads\": $AVAILABLE_THREADS}, \"idle_algos\": [\"$idle_algo_id\"]}")
            ;;
        "xelis-cpu")
            algo_list+=("{\"id\": \"xelis-cpu\", \"algo\": \"xelis_v2\", \"pool\": \"$POOL_XELIS\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$XELIS_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"cpu\", \"threads\": $AVAILABLE_THREADS}, \"idle_algos\": [\"$idle_algo_id\"]}")
            ;;
    esac

    # Add idle algorithm after main algorithm
    if [[ "$GPU_IDLE_COMMAND" == "qubic" || "$GPU_IDLE_COMMAND" == "qubic_solo" ]]; then
        download_qubic_miner
        local pps_value="true"
        if [[ "$GPU_IDLE_COMMAND" == "qubic_solo" ]]; then
            pps_value="false"
        fi
        create_qubic_appsettings "gpu" "$pps_value" "$QUBIC_ADDRESS"
        create_qubic_wrapper
        idle_algo_id="qubic-gpu"
        algo_list+=("{\"id\": \"qubic-gpu\", \"command\": \"$QLI_WRAPPER\"}")
    elif [[ "$GPU_IDLE_COMMAND" == "tari" ]]; then
        idle_algo_id="tari-gpu"
        # UPDATED: Add password and remove idle_algos for tari-gpu
        algo_list+=("{\"id\": \"tari-gpu\", \"algo\": \"tari_sha3x\", \"pool\": \"$POOL_TARI\", \"worker_name\": \"$WORKER_NAME\", \"address\": \"$TARI_ADDRESS\", \"password\": \"x\", \"config\": {\"type\": \"gpu\", \"option\": \"all\"}}")
    elif [[ -n "$GPU_IDLE_COMMAND" ]]; then
        idle_algo_id="my-idle-command"
        algo_list+=("{\"id\": \"my-idle-command\", \"command\": \"$GPU_IDLE_COMMAND\"}")
    fi
    if [[ "$CPU_IDLE_COMMAND" == "qubic" || "$CPU_IDLE_COMMAND" == "qubic_solo" ]]; then
        download_qubic_miner
        local pps_value="true"
        if [[ "$CPU_IDLE_COMMAND" == "qubic_solo" ]]; then
            pps_value="false"
        fi
        create_qubic_appsettings "cpu" "$pps_value" "$QUBIC_ADDRESS"
        create_qubic_wrapper
        idle_algo_id="qubic-cpu"
        algo_list+=("{\"id\": \"qubic-cpu\", \"command\": \"$QLI_WRAPPER\"}")
    fi

    # Update idle_algos in the main algorithm entry with the correct idle_algo_id
    if [[ -n "$idle_algo_id" ]]; then
        for i in "${!algo_list[@]}"; do
            algo_list[$i]=$(echo "${algo_list[$i]}" | jq --arg idle_algo_id "$idle_algo_id" '.idle_algos = [$idle_algo_id]')
        done
    fi

    SELECTED_JSON=$(printf '%s\n' "$selected_algo" | jq -R . | jq -s .)
    ALGO_LIST_JSON=$(printf '%s\n' "${algo_list[@]}" | jq -s .)

    if [[ -z "$SELECTED_JSON" || "$SELECTED_JSON" == "[]" ]]; then
        echo "[OXZD] ERROR: Keine Algorithmen ausgewählt!"
        exit 1
    fi

    jq -n --argjson selected "$SELECTED_JSON" --argjson algo_list "$ALGO_LIST_JSON" \
      '{"selected": $selected, "algo_list": $algo_list}' > "$CONFIG_FILE"

    if [[ ! -s "$CONFIG_FILE" ]]; then
        echo "[OXZD] ERROR: oxzd_config.json konnte nicht erstellt werden!"
        cat "$CONFIG_FILE"
        exit 1
    fi
    echo "[OXZD] Config file $CONFIG_FILE generated successfully."
}

# Bestimme den Hauptalgorithmus
SELECTED_ALGO=""
if [[ -n "$MAIN_ALGO_CPU" ]]; then
    if [[ "$MAIN_ALGO_CPU" == "neptune" ]]; then
        SELECTED_ALGO="neptune-cpu"
    elif [[ "$MAIN_ALGO_CPU" == "xelis" ]]; then
        SELECTED_ALGO="xelis-cpu"
    fi
elif [[ -n "$MAIN_ALGO_GPU" ]]; then
    if [[ "$MAIN_ALGO_GPU" == "neptune" ]]; then
        SELECTED_ALGO="neptune-gpu"
    fi
fi

if [[ -z "$SELECTED_ALGO" ]]; then
    echo "[OXZD] ERROR: Kein gültiger Algorithmus ausgewählt! MAIN_ALGO_GPU=$MAIN_ALGO_GPU, MAIN_ALGO_CPU=$MAIN_ALGO_CPU"
    exit 1
fi

# Erstelle die anfängliche Konfiguration
create_config "$SELECTED_ALGO"

# Debug: Print generated config
echo "[OXZD] Generated oxzd_config.json:"
cat "$CONFIG_FILE"

# Starte Miner
cd "$MINER_DIR" || { echo "[OXZD] ERROR: Kann Verzeichnis $MINER_DIR nicht öffnen"; exit 1; }
chmod +x oxzd

echo "[OXZD] Starte Miner mit Algorithmus: $SELECTED_ALGO"
case "$SELECTED_ALGO" in
    "neptune-gpu")
        ./oxzd run --algos neptune-gpu 2>&1 | tee -a "$LOGFILE"
        ;;
    "neptune-cpu")
        ./oxzd run --algos neptune-cpu 2>&1 | tee -a "$LOGFILE"
        ;;
    "xelis-cpu")
        ./oxzd run --algos xelis-cpu 2>&1 | tee -a "$LOGFILE"
        ;;
    *)
        echo "[OXZD] WARN: Unbekannter Algorithmus: $SELECTED_ALGO"
        exit 1
        ;;
esac
